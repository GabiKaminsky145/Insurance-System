package com.insurance.insurance_system.exceptions.ClientExceptions;

public class DuplicateClientException extends RuntimeException {
    public DuplicateClientException(String id) {
        super("Client already exists with id: " + id);
    }
}
